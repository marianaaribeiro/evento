import Login from "../components/template/Login";

export default function LoginPage() {
    return <Login />;
}